# Meta_Reader

This Plugin Scans all Simplify 3D and Cura Gcode files for metadata and saves it locally to the printer.

## Setup

Install via the bundled [Plugin Manager](https://github.com/foosel/OctoPrint/wiki/Plugin:-Plugin-Manager)
or manually using this URL:

    https://github.com/Robo3D/Meta-Reader/archive/master.zip

